package mychatapp;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class MessageService {
    private final List<Message> sentMessages = new ArrayList<>();
    private final List<Message> disregardedMessages = new ArrayList<>();
    private final List<String> messageHashes = new ArrayList<>();
    private final List<String> messageIDs = new ArrayList<>();
    private final MessageRepository repository = new MessageRepository();
    private int sentCount = 0;

    public Message createMessage(String recipient, String text) {
        Message msg = new Message(recipient, text);
        messageIDs.add(msg.getMessageID());
        messageHashes.add(msg.createMessageHash());
        return msg;
    }

    public void sendMessage(Message message) {
        sentMessages.add(message);
        repository.save(message);
        sentCount++;
    }

    public void disregardMessage(Message message) {
        disregardedMessages.add(message);
    }

    public void storeMessage(Message message) {
        repository.save(message);
    }

    // Array access methods
    public List<Message> getSentMessages() {
        return new ArrayList<>(sentMessages);
    }

    public List<Message> getDisregardedMessages() {
        return new ArrayList<>(disregardedMessages);
    }

    public List<Message> getStoredMessages() {
        return repository.loadAll();
    }

    public List<String> getMessageHashes() {
        return new ArrayList<>(messageHashes);
    }

    public List<String> getMessageIDs() {
        return new ArrayList<>(messageIDs);
    }

    // Feature implementations
    public String displaySendersAndRecipients() {
        return sentMessages.stream()
            .map(m -> "From: System | To: " + m.getRecipient())
            .collect(Collectors.joining("\n"));
    }

    public String getLongestMessage() {
        return sentMessages.stream()
            .max(Comparator.comparingInt(m -> m.getMessageText().length()))
            .map(Message::getMessageText)
            .orElse("No messages sent");
    }

    public String searchByMessageID(String messageID) {
        return sentMessages.stream()
            .filter(m -> m.getMessageID().equals(messageID))
            .findFirst()
            .map(m -> "Recipient: " + m.getRecipient() + "\nMessage: " + m.getMessageText())
            .orElse("Message not found");
    }

    public String searchByRecipient(String recipient) {
        List<Message> matches = sentMessages.stream()
            .filter(m -> m.getRecipient().equals(recipient))
            .collect(Collectors.toList());
        
        if (matches.isEmpty()) return "No messages found for recipient";
        
        StringBuilder result = new StringBuilder();
        matches.forEach(m -> 
            result.append("Message: ").append(m.getMessageText()).append("\n"));
        return result.toString();
    }

    public boolean deleteByHash(String hash) {
        return sentMessages.removeIf(m -> m.createMessageHash().equals(hash));
    }

    public String generateFullReport() {
        StringBuilder report = new StringBuilder("MESSAGE REPORT\n\n");
        sentMessages.forEach(m -> 
            report.append(m.printMessageDetails()).append("\n\n"));
        return report.toString();
    }

    public int getSentCount() {
        return sentCount;
    }

    Iterable<Message> getRecentMessages() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}