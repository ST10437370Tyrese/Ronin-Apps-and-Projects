package mychatapp;

public class UserService {
    private String username;
    private String password;

    public boolean checkUsername(String username) {
        return username != null && username.contains("_") && username.length() <= 5;
    }

    public boolean checkPasswordComplexity(String password) {
        return password != null &&
               password.length() >= 8 &&
               password.matches(".*[A-Z].*") &&
               password.matches(".*\\d.*") &&
               password.matches(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?].*");
    }

    public boolean checkCellphoneNumber(String cell) {
        return cell != null && cell.matches("0\\d{9}");
    }

    public String registerUser(String username, String password, String cell) {
        if (!checkUsername(username)) {
            return "Username must contain '_' and be ≤5 characters";
        }
        if (!checkPasswordComplexity(password)) {
            return "Password needs 8+ chars with uppercase, number, and special character";
        }
        if (!checkCellphoneNumber(cell)) {
            return "Invalid SA phone number (must start with 0 and be 10 digits)";
        }
        
        this.username = username;
        this.password = password;
        return "Account created successfully!";
    }

    public boolean loginUser(String username, String password) {
        return username != null && password != null && 
               username.equals(this.username) && password.equals(this.password);
    }

    public String getLoginStatus(boolean isLoggedIn, String username) {
        return isLoggedIn ? "Welcome " + username + ", it is great to see you again." 
                         : "Username or password incorrect, please try again.";
    }
}