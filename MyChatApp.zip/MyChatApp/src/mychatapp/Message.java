package mychatapp;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class Message {
    private final String messageID;
    private final String recipient;
    private final String messageText;
    private final String timestamp;

    public Message(String recipient, String messageText) {
        if (recipient == null || !recipient.matches("0\\d{9}")) {
            throw new IllegalArgumentException("Invalid recipient number");
        }
        if (messageText == null || messageText.length() > 250) {
            throw new IllegalArgumentException("Message must be ≤250 characters");
        }
        
        this.messageID = generateMessageID();
        this.recipient = recipient;
        this.messageText = messageText;
        this.timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
    }

    private String generateMessageID() {
        Random random = new Random();
        return String.valueOf(1000000000L + random.nextInt(900000000));
    }

    public String createMessageHash() {
        String[] words = messageText.split("\\s+");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 0 ? words[words.length-1] : "";
        return (messageID.substring(0, 2) + ":" + firstWord + lastWord).toUpperCase();
    }

    public String printMessageDetails() {
        return String.format(
            "Message ID: %s\nRecipient: %s\nTimestamp: %s\nMessage: %s\nHash: %s",
            messageID, recipient, timestamp, messageText, createMessageHash()
        );
    }

    // Getters
    public String getMessageID() { return messageID; }
    public String getRecipient() { return recipient; }
    public String getMessageText() { return messageText; }
    public String getTimestamp() { return timestamp; }
}