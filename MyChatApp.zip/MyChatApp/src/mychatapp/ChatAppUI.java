package mychatapp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ChatAppUI {
    private final UserService userService = new UserService();
    private final MessageService messageService = new MessageService();
    private int maxMessages = 0;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ChatAppUI().showCreateAccountFrame());
    }

    private void showCreateAccountFrame() {
        JFrame frame = new JFrame("Chat App - Create Account");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 450);
        frame.setLayout(new GridLayout(6, 2));

        JLabel userLabel = new JLabel("Username:");
        JTextField userField = new JTextField();

        JLabel passLabel = new JLabel("Password:");
        JPasswordField passField = new JPasswordField();

        JLabel phoneLabel = new JLabel("Phone Number (+27):");
        JTextField phoneField = new JTextField();

        JButton submitButton = new JButton("Create Account");
        JTextArea messageArea = new JTextArea();
        messageArea.setLineWrap(true);
        messageArea.setWrapStyleWord(true);
        messageArea.setEditable(false);

        frame.add(userLabel);
        frame.add(userField);
        frame.add(passLabel);
        frame.add(passField);
        frame.add(phoneLabel);
        frame.add(phoneField);
        frame.add(new JLabel());
        frame.add(submitButton);
        frame.add(new JLabel("Result:"));
        frame.add(messageArea);

        submitButton.addActionListener(e -> {
            String result = userService.registerUser(
                userField.getText(),
                new String(passField.getPassword()),
                phoneField.getText()
            );
            
            messageArea.setText(result);
            
            if (result.equals("Account created successfully!")) {
                showLoginFrame();
                frame.dispose();
            }
        });

        frame.setVisible(true);
    }

    private void showLoginFrame() {
        JFrame frame = new JFrame("Chat App - Login");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 150);
        frame.setLayout(new GridLayout(3, 2));

        JLabel loginUserLabel = new JLabel("Username:");
        JTextField loginUserField = new JTextField();

        JLabel loginPassLabel = new JLabel("Password:");
        JPasswordField loginPassField = new JPasswordField();

        JButton loginButton = new JButton("Login");
        JLabel loginMessageLabel = new JLabel();

        frame.add(loginUserLabel);
        frame.add(loginUserField);
        frame.add(loginPassLabel);
        frame.add(loginPassField);
        frame.add(new JLabel());
        frame.add(loginButton);
        frame.add(new JLabel());
        frame.add(loginMessageLabel);

        loginButton.addActionListener(e -> {
            boolean success = userService.loginUser(
                loginUserField.getText(),
                new String(loginPassField.getPassword())
            );
            
            loginMessageLabel.setText(userService.getLoginStatus(success, loginUserField.getText()));
            
            if (success) {
                showMainMenu();
                frame.dispose();
            }
        });

        frame.setVisible(true);
    }

    private void showMainMenu() {
        JFrame frame = new JFrame("QuickChat - Main Menu");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setLayout(new BorderLayout());

        JTextArea welcomeArea = new JTextArea("Welcome to QuickChat.\n\nPlease select an option:");
        welcomeArea.setEditable(false);
        welcomeArea.setFont(new Font("Arial", Font.BOLD, 14));
        
        JPanel buttonPanel = new JPanel(new GridLayout(4, 1, 10, 10));
        
        JButton sendMessagesButton = new JButton("1) Send Messages");
        JButton showMessagesButton = new JButton("2) Show Messages");
        JButton manageMessagesButton = new JButton("3) Manage Messages");
        JButton quitButton = new JButton("4) Quit");
        
        buttonPanel.add(sendMessagesButton);
        buttonPanel.add(showMessagesButton);
        buttonPanel.add(manageMessagesButton);
        buttonPanel.add(quitButton);
        
        frame.add(welcomeArea, BorderLayout.NORTH);
        frame.add(buttonPanel, BorderLayout.CENTER);
        
        sendMessagesButton.addActionListener(e -> {
            String input = JOptionPane.showInputDialog(frame, "How many messages do you want to send?");
            try {
                maxMessages = Integer.parseInt(input);
                if (maxMessages > 0) {
                    showMessageInputFrame();
                    frame.dispose();
                } else {
                    JOptionPane.showMessageDialog(frame, "Please enter a positive number");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Please enter a valid number");
            }
        });
        
        showMessagesButton.addActionListener(e -> {
            StringBuilder sb = new StringBuilder("Recent Messages:\n\n");
            for (Message msg : messageService.getRecentMessages()) {
                sb.append(msg.printMessageDetails()).append("\n\n");
            }
            JOptionPane.showMessageDialog(frame, sb.toString());
        });
        
        manageMessagesButton.addActionListener(e -> {
            showMessageManagementFrame();
            frame.dispose();
        });
        
        quitButton.addActionListener(e -> System.exit(0));
        
        frame.setVisible(true);
    }

    private void showMessageInputFrame() {
        JFrame frame = new JFrame("Send Messages");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 400);
        frame.setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(4, 2, 5, 5));
        
        JLabel recipientLabel = new JLabel("Recipient Phone Number (+27):");
        JTextField recipientField = new JTextField();
        
        JLabel messageLabel = new JLabel("Message (max 250 chars):");
        JTextArea messageArea = new JTextArea();
        messageArea.setLineWrap(true);
        messageArea.setWrapStyleWord(true);
        JScrollPane messageScroll = new JScrollPane(messageArea);
        
        JButton sendButton = new JButton("Send Message");
        JButton backButton = new JButton("Back to Menu");
        
        inputPanel.add(recipientLabel);
        inputPanel.add(recipientField);
        inputPanel.add(messageLabel);
        inputPanel.add(messageScroll);
        inputPanel.add(new JLabel());
        inputPanel.add(sendButton);
        inputPanel.add(new JLabel());
        inputPanel.add(backButton);
        
        JTextArea statusArea = new JTextArea();
        statusArea.setEditable(false);
        statusArea.setLineWrap(true);
        statusArea.setWrapStyleWord(true);
        
        frame.add(inputPanel, BorderLayout.NORTH);
        frame.add(new JScrollPane(statusArea), BorderLayout.CENTER);
        
        sendButton.addActionListener(e -> {
            if (messageService.getSentCount() >= maxMessages) {
                JOptionPane.showMessageDialog(frame, 
                    "You've reached your message limit (" + maxMessages + ")");
                return;
            }
            
            try {
                Message msg = messageService.createMessage(
                    recipientField.getText(),
                    messageArea.getText()
                );
                
                String[] options = {"Send Message", "Disregard Message", "Store for Later"};
                int choice = JOptionPane.showOptionDialog(
                    frame, 
                    "What would you like to do with this message?",
                    "Message Options",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    options,
                    options[0]
                );
                
                if (choice == 0) { // Send
                    messageService.sendMessage(msg);
                    statusArea.append("Message sent successfully!\n");
                    statusArea.append(msg.printMessageDetails() + "\n\n");
                    
                    if (messageService.getSentCount() >= maxMessages) {
                        JOptionPane.showMessageDialog(frame, 
                            "You've sent all " + maxMessages + " messages");
                        showMainMenu();
                        frame.dispose();
                    }
                } else if (choice == 1) { // Disregard
                    messageService.disregardMessage(msg);
                    statusArea.append("Message disregarded.\n");
                } else { // Store
                    messageService.storeMessage(msg);
                    statusArea.append("Message stored for later.\n");
                }
                
                recipientField.setText("");
                messageArea.setText("");
            } catch (IllegalArgumentException ex) {
                statusArea.append("Error: " + ex.getMessage() + "\n");
            }
        });
        
        backButton.addActionListener(e -> {
            showMainMenu();
            frame.dispose();
        });
        
        frame.setVisible(true);
    }

    private void showMessageManagementFrame() {
        JFrame frame = new JFrame("Message Management");
        frame.setSize(600, 400);
        frame.setLayout(new BorderLayout());

        JTextArea outputArea = new JTextArea();
        outputArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputArea);

        JPanel buttonPanel = new JPanel(new GridLayout(7, 1));

        String[] options = {
            "1. Show senders/recipients",
            "2. Show longest message",
            "3. Search by message ID",
            "4. Search by recipient",
            "5. Delete by message hash",
            "6. Generate full report",
            "7. Back to main menu"
        };

        for (String option : options) {
            JButton button = new JButton(option);
            button.addActionListener(e -> handleManagementOption(option, outputArea, frame));
            buttonPanel.add(button);
        }

        frame.add(buttonPanel, BorderLayout.WEST);
        frame.add(scrollPane, BorderLayout.CENTER);
        frame.setVisible(true);
    }

    private void handleManagementOption(String option, JTextArea outputArea, JFrame frame) {
        switch (option) {
            case "1. Show senders/recipients":
                outputArea.setText(messageService.displaySendersAndRecipients());
                break;
                
            case "2. Show longest message":
                outputArea.setText("Longest message:\n" + messageService.getLongestMessage());
                break;
                
            case "3. Search by message ID":
                String id = JOptionPane.showInputDialog(frame, "Enter message ID:");
                outputArea.setText(messageService.searchByMessageID(id));
                break;
                
            case "4. Search by recipient":
                String recipient = JOptionPane.showInputDialog(frame, "Enter recipient number:");
                outputArea.setText(messageService.searchByRecipient(recipient));
                break;
                
            case "5. Delete by message hash":
                String hash = JOptionPane.showInputDialog(frame, "Enter message hash:");
                boolean deleted = messageService.deleteByHash(hash);
                outputArea.setText(deleted ? "Message deleted" : "Message not found");
                break;
                
            case "6. Generate full report":
                outputArea.setText(messageService.generateFullReport());
                break;
                
            case "7. Back to main menu":
                frame.dispose();
                showMainMenu();
                break;
        }
    }
}