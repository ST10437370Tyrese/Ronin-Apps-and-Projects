package mychatapp;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

public class MessageRepository {
    private static final String FILE_NAME = "messages.json";

    @SuppressWarnings("unchecked")
    public void save(Message message) {
        JSONArray messagesArray = loadExistingMessages();
        
        JSONObject messageObj = new JSONObject();
        messageObj.put("messageID", message.getMessageID());
        messageObj.put("recipient", message.getRecipient());
        messageObj.put("messageText", message.getMessageText());
        messageObj.put("timestamp", message.getTimestamp());
        messageObj.put("messageHash", message.createMessageHash());
        
        messagesArray.add(messageObj);

        try (FileWriter writer = new FileWriter(FILE_NAME)) {
            writer.write(messagesArray.toJSONString());
        } catch (Exception e) {
            System.err.println("Error saving message: " + e.getMessage());
        }
    }

    public List<Message> loadAll() {
        JSONArray messagesArray = loadExistingMessages();
        List<Message> messages = new ArrayList<>();
        
        for (Object obj : messagesArray) {
            JSONObject jsonMsg = (JSONObject) obj;
            try {
                Message msg = new Message(
                    (String) jsonMsg.get("recipient"),
                    (String) jsonMsg.get("messageText")
                );
                messages.add(msg);
            } catch (IllegalArgumentException e) {
                System.err.println("Skipping invalid message: " + e.getMessage());
            }
        }
        return messages;
    }

    private JSONArray loadExistingMessages() {
        File file = new File(FILE_NAME);
        if (!file.exists()) return new JSONArray();

        try (FileReader reader = new FileReader(file)) {
            JSONParser parser = new JSONParser();
            return (JSONArray) parser.parse(reader);
        } catch (Exception e) {
            System.err.println("Error loading messages: " + e.getMessage());
            return new JSONArray();
        }
    }
}