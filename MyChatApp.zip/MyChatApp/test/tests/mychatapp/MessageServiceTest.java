package mychatapp;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

public class MessageServiceTest {
    private MessageService service;
    
    @BeforeEach
    void setUp() {
        service = new MessageService();
        // Clear any existing messages
        service.getSentMessages().clear();
    }

    @Test
    void testSendMessage() {
        service.sendMessage(new Message("0838884567", "Test"));
        assertEquals(1, service.getSentMessages().size());
    }

    @Test
    void testLongestMessage() {
        service.sendMessage(new Message("0123456789", "Short"));
        service.sendMessage(new Message("0838884567", "Longer message text"));
        
        assertEquals("Longer message text", service.getLongestMessage());
    }

    @Test
    void testSearchByRecipient() {
        service.sendMessage(new Message("0838884567", "Message 1"));
        service.sendMessage(new Message("0838884567", "Message 2"));
        
        String result = service.searchByRecipient("0838884567");
        assertTrue(result.contains("Message 1"));
        assertTrue(result.contains("Message 2"));
    }
}