package mychatapp;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

public class MessageRepositoryTest {
    private final MessageRepository repository = new MessageRepository();
    private final Message testMessage = new Message("0838884567", "It is dinner time!");
    
    @Test
    void testMessageStorageAndRetrieval() {
        repository.save(testMessage);
        
        List<Message> messages = repository.loadAll();
        assertFalse(messages.isEmpty());
        assertEquals("0838884567", messages.get(0).getRecipient());
        assertEquals("It is dinner time!", messages.get(0).getMessageText());
    }
    
    @Test
    void testMultipleMessagesStorage() {
        repository.save(testMessage);
        repository.save(new Message("0838884567", "Where are you?"));
        
        List<Message> messages = repository.loadAll();
        assertTrue(messages.size() >= 2);
    }
}