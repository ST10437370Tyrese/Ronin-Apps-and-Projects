package mychatapp;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Random;

public class MessageTest {
    private Message message;
    
    @BeforeEach
    void setUp() {
        message = new Message("0838884567", "Test message");
    }

    @Test
    void testMessageCreation() {
        assertNotNull(message);
        assertEquals("0838884567", message.getRecipient());
    }

    @Test
    void testMessageIDFormat() {
        String id = message.getMessageID();
        assertNotNull(id);
        assertEquals(10, id.length());
        assertTrue(id.matches("\\d+"));
    }

    @Test
    void testInvalidRecipient() {
        assertThrows(IllegalArgumentException.class, 
            () -> new Message("invalid", "Test"));
    }

    @Test
    void testHashGeneration() {
        String hash = message.createMessageHash();
        assertTrue(hash.startsWith(message.getMessageID().substring(0, 2) + ":"));
    }
}