package mychatapp;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class UserServiceTest {
    private final UserService service = new UserService();
    
    @Test
    void testUsernameValidation() {
        assertTrue(service.checkUsername("a_b"));
        assertTrue(service.checkUsername("_abc"));
        
        assertFalse(service.checkUsername("abcde")); // No underscore
        assertFalse(service.checkUsername("a_bcd")); // Too long
        assertFalse(service.checkUsername(null));
    }
    
    @Test
    void testPasswordComplexity() {
        assertTrue(service.checkPasswordComplexity("ValidPass1!"));
        assertFalse(service.checkPasswordComplexity("weak"));
        assertFalse(service.checkPasswordComplexity("NoSpecial1"));
        assertFalse(service.checkPasswordComplexity("nonumbers!"));
        assertFalse(service.checkPasswordComplexity("NOLOWERCASE1!"));
    }
    
    @Test
    void testCellphoneValidation() {
        assertTrue(service.checkCellphoneNumber("0123456789"));
        assertFalse(service.checkCellphoneNumber("1123456789")); // Doesn't start with 0
        assertFalse(service.checkCellphoneNumber("012345678")); // Too short
        assertFalse(service.checkCellphoneNumber(null));
    }
    
    @Test
    void testUserRegistration() {
        String result = service.registerUser("a_b", "ValidPass1!", "0123456789");
        assertEquals("Account created successfully!", result);
        
        result = service.registerUser("abc", "ValidPass1!", "0123456789");
        assertTrue(result.contains("Username"));
        
        result = service.registerUser("a_b", "weak", "0123456789");
        assertTrue(result.contains("Password"));
        
        result = service.registerUser("a_b", "ValidPass1!", "1123456789");
        assertTrue(result.contains("phone number"));
    }
}